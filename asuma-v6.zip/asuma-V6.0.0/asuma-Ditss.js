const bot = "asuma multi device"


/*/✨ script asuma toki by ditss✨
©powered by ♞𝘿I̶T̶𝗦㐅᭄

#my contact 
+6281513607731

#my saluran 
https://whatsapp.com/channel/0029VaimJO0E50UaXv9Z1J0L

# my you tube
https://youtube.com/@paaditt

#my res api🔥
- api.ditss.my.id

*/Asuma versi lama ( old )
const old = 
[
"https://www.mediafire.com/file/z36wk9xqzo9vl8q/AsumA_V2.7.zip/file",

"https://www.mediafire.com/file/0rapm6bphlnbg18/asuma-apdateV2.8.zip/file",

"https://www.mediafire.com/file/3njshun2go4ruam/asuma-beton.zip/file",

"https://www.mediafire.com/file/nob2wegajnnfzrr/asuma-%25F0%259F%2592%258D.zip/file",

"https://www.mediafire.com/file/ji7n16prxeoigw1/asuma-full-button.zip/file",

"https://www.mediafire.com/file/0uf3utt3g5cj0mz/asuma-njir-lah.zip/file",

"https://www.mediafire.com/file/01bv4ac35zpk4b6/AsUmA.zip/file",

"https://www.mediafire.com/file/ttwkib3x9xgnnue/AsumaFix.zip/file",

"https://www.mediafire.com/file/qoii7ucsz202re7/AsumaMultiKontol.zip/file",

"https://www.mediafire.com/file/8e97suhminj76nd/asumaV2.9.zip/file",

"https://www.mediafire.com/file/f1r0oody7bzkq3i/asumaV3.0.0-percobaan.zip/file",

"https://www.mediafire.com/file/p1lho83jmy6483s/asumaVersion3.5.0.zip/file",

"https://www.mediafire.com/file/hhf19d1uqfhv0zx/%25F0%259F%2597%25BFAsuma-Si-Bjir-Lahh%25F0%259F%2598%259D.zip/file"
]