const chalk = require('chalk');
const figlet = require('figlet');
const os = require('os');

const text = figlet.textSync('WhatsApp Bot', {
  font: 'Slant',
  horizontalLayout: 'default',
  verticalLayout: 'default',
  width: 80,
  whitespaceBreak: false
});

console.log(chalk.black.bold.bgWhite(text.split('\n').map(line => '  ' + line).join('\n')));
console.log(chalk.white.bold(text));

console.log(chalk.yellow(`\n${chalk.blue('Created By Ditss - kiyoo')}\n`));
console.log(chalk.white.bold(`▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
${chalk.green.bold("asuma - ai")}


${chalk.green.bold("📂 Your Server Info:")} 
• Platform: ${os.platform()}
• Architecture: ${os.arch()}
• CPU Model: ${os.cpus()[0].model}
• Total Memory: ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB
• Free Memory: ${(os.freemem() / 1024 / 1024).toFixed(2)} MB
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
`));