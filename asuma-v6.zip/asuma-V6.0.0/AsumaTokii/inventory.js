const fs = require("fs");
const path = require("path");

const inventoryPath = path.join(__dirname, "inventory.json");

function loadInventory() {
    if (!fs.existsSync(inventoryPath)) {
        fs.writeFileSync(inventoryPath, JSON.stringify([], null, 2));
    }
    return JSON.parse(fs.readFileSync(inventoryPath));
}

function saveInventory(data) {
    fs.writeFileSync(inventoryPath, JSON.stringify(data, null, 2));
}

function addItemToUser(userId, item) {
    let inventory = loadInventory();
    let userInventory = inventory.find(user => user.id === userId);

    if (!userInventory) {
        userInventory = { id: userId, items: [] };
        inventory.push(userInventory);
    }

    let existingItem = userInventory.items.find(i => i.id === item.id);
    if (existingItem) {
        existingItem.quantity += 1; // Jika barang sudah ada, tambahkan jumlahnya
    } else {
        userInventory.items.push({ ...item, quantity: 1 }); // Jika belum ada, tambahkan barang baru dengan quantity 1
    }

    saveInventory(inventory);
}

function getUserInventory(userId) {
    let inventory = loadInventory();
    let userInventory = inventory.find(user => user.id === userId);
    return userInventory ? userInventory.items : [];
}

function removeItemFromUser(userId, itemId) {
    let inventory = loadInventory();
    let userInventory = inventory.find(user => user.id === userId);

    if (userInventory) {
        let itemIndex = userInventory.items.findIndex(i => i.id === itemId);
        if (itemIndex !== -1) {
            if (userInventory.items[itemIndex].quantity > 1) {
                userInventory.items[itemIndex].quantity -= 1; // Kurangi stok dulu
            } else {
                userInventory.items.splice(itemIndex, 1); // Hapus item jika stok habis
            }

            if (userInventory.items.length === 0) {
                inventory = inventory.filter(user => user.id !== userId);
            }

            saveInventory(inventory);
        }
    }
}

module.exports = { addItemToUser, getUserInventory, removeItemFromUser };