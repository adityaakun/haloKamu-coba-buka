//require('./setting/payment');
require('./setting/setting-harga');
require('./sistem-asuma/aditt');
require('./setting/Settings-Store');

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")
global.typemenu = 'v2'// setting tampilan menu

//setting Auto readsw
global.autoreadsw = true
global.emojiSw = ["🗿","😹","🥹","🥺","😍"]
//SETTING MY OWNER/BOT
global.my = {
	yt: "https://youtube.com/@paaditt?si=ElVYrC7CtH3ETTS6",
	webprib: "https://ditss.vercel.app/",
	ig: "https://www.instagram.com/dits.v2?igsh=NmE3Mmt0MWRmc2Uz",
	tiktok: "https://www.tiktok.com/@paadit?_t=ZS-8v3k5dYzrho&_r=1",
	gh: "https://github.com/ditss-dev",
    ch: "https://whatsapp.com/channel/0029VaimJO0E50UaXv9Z1J0L",
	gc: "https://chat.whatsapp.com/IEGSv0bv5gC2etNuXJajd0",
	idgc: "120363179230732743@g.us",
	idch: "120363314209665405@newsletter"
}

// SETTING OWNER 
  global.ownerName = "tynaa"
global.namabot = "asuma multi device" 
global.botname2 = 'asuma md'
global.namaowner = "Ditss"
global.packname = "asuma"
global.author = "ditss"
global.versi = version
global.owner = [ "6281513607731@s.whatsapp.net", "6283147462228@s.whatsapp.net"
]
  global.noowner = '6281513607731'
  global.ownername = 'Ditss'
  global.gcwa = "https://chat.whatsapp.com/GmY4GlfkmpyL0fdMRUKdd2"
  global.stickerthink = "asuma - md"
  global.videourl = "https://pomf2.lain.la/f/aeyg2q9.mp4"
  global.pathSimple = "https://img12.pixhost.to/images/1256/581188763_ditss.jpg"
  global.qrmu = "https://img12.pixhost.to/images/1256/581188763_ditss.jpg"
  global.pendaftaransal = "120363368153013154@newsletter"
  global.idsalmusik = "120363392257209587@newsletter"
  global.botName = "asuma md"
  global.footer = "2025 - 2026"
  global.fotoDonasi = "./media/dana.jpg",
  global.sessionName = "novsession",
  global.idsaluran = "120363338102578213@newsletter"
  global.namasaluran = "🐣⚡🐣"
  global.videogif = "https://files.catbox.moe/heoao7.mp4"
  global.pathimg = "https://img12.pixhost.to/images/1256/581188763_ditss.jpg"
  global.qcAiName = "QC - AI",
  global.BotKey = "yoau5Tt3fZQSouo",
  global.XznKey = "rafael"
  global.audio_di_bagian_menu = "./media/menu.mp3"
  global.audio_di_bagian_owner = "./media/owner.mp3"
  global.menu = "v7"
  global.menumusik= "https://files.catbox.moe/d57wsf.mp3"
  global.vapis = 'https://vapis.my.id'
// setting bot 
/*
true = nyala 
false = mati
*/
  global.kirto = false
  global.kirsan = false
  global.auto_welcomeMsg = true
  global.auto_leaveMsg = true
  global.autobackup = true
  global.antiViewOnce = false
  global.antiDelete = false
  global.autobio = false
  global.notifRegister = true
  global.onlyRegister = false
  global.anticall = true
  global.gruponly = false
  global.pconly = false
  global.autorespond = false
  global.autoblok212 = true
  global.autoread = true
  global.prefix = true
  global.limitCount = 15
  global.toxicCount = 5
  global.Antilink2Count = 10
// SETRING LIMIT USER 
  global.gcount = {
    prem: 500,
    user: 25
  }
// setting respon message 
global.mess = {
        wait: "*ʟᴏᴀᴅɪɴɢ... 🐎*",
        Iv: "ʟɪɴᴋ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪᴘᴀᴋᴀɪ ʟᴀɢɪ..",
        api: "ups api pending",
        slh: "ᴜᴘs, ᴛᴇʀᴊᴀᴅɪ ᴋᴇsᴀʟᴀʜᴀɴ, sɪʟᴀʜᴋᴀɴ ᴄᴏʙᴀ ʟᴀɢɪ.",
    OnlyGrup: "only group chat",
    OnlyPM: "only private chat",
    GrupAdmin: "only admin group",
    BotAdmin: "bot must be admin",
    OnlyOwner: "owner only features",
    OnlyPrem: "this feature can only be used by premium users😝"
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})