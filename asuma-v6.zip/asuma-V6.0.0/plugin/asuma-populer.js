const fs = require("fs")
const os = require('os');

//let handler = async (m, { Ditss, toIDR, isCreator, Reply, command, isPremium, capital, isCmd, example, text, runtime, qtext, qlocJpm, qmsg, mime, sleep, botNumber, nomore, qkontak, asumaSaldo, ditsganteng, prefix, reply, text, pickRandom, replyAi }) => {
//let totalreg = Object.keys(db.list().user).length
let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime, toIDR, qkontak, asumaSaldo, ditsganteng, pickRandom, readmore,fetchJson, prefix, sleep, salam, totalfitur, yatimm}) => {
    //disin
const xmenu_oh = `${global.menupopuler}`

const resize = async(buffer, ukur1, ukur2) => {
 return new Promise(async(resolve, reject) => {
 let jimp = require('jimp')
 var baper = await jimp.read(buffer);
 var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
 resolve(ab)
 })
}

Ditss.sendMessage(m?.chat, {
    document: fs.readFileSync("./package.json"),
    jpegThumbnail: fs.readFileSync("./media/menu.jpg"),
    fileName: `${global.namabot} - populer`,
    fileLength: 99999999999999,
    pageCount: "100",
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
//bts
 caption: xmenu_oh,
 footer: `\npowered by ${global.namaowner}`,
  buttons: [
  /*{
    buttonId: '.botjelek',
    buttonText: {
      displayText: 'back'
    },
    type: 1,
  },*/
  {
    buttonId: '.botjelek',
    buttonText: {
      displayText: 'back'
    },
    type: 1,
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: '༎༎',
        sections: [
          {
            title: 'Ditss - 2025',
            highlight_label: 'terlaris✓',
            rows: [

              {
                header: 'Menu Populer 🐣',
                title: 'menampilkan menu populer',
                description: 'yang sering di pake banyak orang',
                id: '.menu-populer',
              },
              {
                header: 'Group Menu🐣',
                title: 'menampilkan menu grupp',
                description: 'yang di butuhkan para atmin grup.',
                id: '.asuma-group',
              },
                             {
                header: 'Game Menu🐣',
                title: 'menampilkan menu game',
                description: 'seru seruan bareng bot, capai saldo anda.',
                id: '.asuma-game',
              },
              {
                header: 'Rpg Menu🐣',
                title: 'menampilkan menu rpg',
                description: 'fitur untuk seru seruan',
                id: '.asuma-rpg',
              },
              {
                header: 'Download Menu🐣',
                title: 'Menampilkan Menu Download',
                description: 'yang cepat dan canggih.',
                id: '.asuma-download',
              },
              {
                header: 'Jadibot menu 🐣',
                title: 'menampilkan menu jadibot',
                description: 'yang bisa jadi bot clone',
                id: '.asuma-jadibot',
              },
              {
                header: 'Bug Menu🐣',
                title: 'menampilkan menu Bug bot',
                description: 'virtek/bug bot',
                id: '.bugmenu',
              },
              {
                header: 'Search Menu🐣',
                title: 'menampilkan menu search',
                description: 'yang canggih dan cepat',
                id: '.asuma-search',

              },
              {
                header: 'Tools Menu🐣',
                title: 'menampilkan menu tools',
                description: 'yang serba bisa dan unik',
                id: '.asuma-tools',
              },
              {
                header: 'Absen Menu🐣',
                title: 'menampilkan menu absen',
                description: 'fitur absen yang khusus Group',
                id: '.asuma-absen',
              },
              {
                header: 'Cerpen Menu🐣',
                title: 'menampilkan menu cerpen',
                description: 'cocok yang suka bacaa',
                id: '.asuma-cerpen',
              },
              {
                header: 'Berita Menu🐣',
                title: 'menampilkan menu berita',
                description: 'cocok yang sering baca/suka berita terbaru',
                id: '.asuma-berita',
              },
              {
                header: 'Sound Menu🐣',
                title: 'menampilkan menu sound',
                description: 'cocok yang sering dengerin musik',
                id: '.asuma-sound',
              },
              {
                header: 'Anime Menu🐣',
                title: 'menampilkan menu anime',
                description: 'cocok yang suka anime/waifu',
                id: '.asuma-anime',
              },
              {
                header: 'photo Menu🐣',
                title: 'menampilkan menu photo',
                description: 'cari photo idol',
                id: '.asuma-photo',
              },
              {
                header: 'Islam Menu🐣',
                title: 'menampilkan menu islami',
                description: 'cocok yang mau belajar surat"',
                id: '.asuma-islam',
              },
              {
                header: 'Asupan Menu🐣',
                title: 'menampilkan menu asupan',
                description: 'cuci mata🗿🥵',
                id: '.asuma-asupan',
              },
              {
                header: 'Nsfw Menu🐣',
                title: 'menampilkan menu nsfw',
                description: 'menu terlarang',
                id: '.asuma-nsfw',
              },
              {
                header: 'store Menu🐣',
                title: 'menampilkan menu store',
                description: 'buy di layanan bot yg di sediakan.',
                id: '.asuma-store',
              },
              {
                header: 'pterodactyl menu🐣',
                title: 'menampilkan menu pterodactyl',
                description: 'server 1',
                id: '.panelmenu',
              },
              {
                header: 'pterodactyl menu🐣',
                title: 'menampilkan menu pterodactyl',
                description: 'server 2',
                id: '.panelmenu2',
              },
              {
                header: 'Owner Menu🐣',
                title: 'menampilkan mennu owner',
                description: `khsus ${global.namaowner}`,
                id: '.asuma-owner',
              },
              {
                header: 'HEADER',
                title: 'TITLE',
                description: 'DESCRIPTION',
                id: 'YOUR ID',
              },
            
              {
                header: 'HEADER',
                title: 'TITLE',
                description: 'DESCRIPTION',
                id: 'YOUR ID',
              },

            ],
          },
        ],
      }),
    },
  },
  ],
 viewOnce: true,
 headerType: 6,
 contextInfo: {
 isForwarded: true,
 forwardingScore: 99999,
mentionedJid: [global.noowner+"@s.whatsapp.net", m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: `${global.namaowner} | ${global.namabot}`,
 mediaType: 1,
 previewType: 1,
 body: `${m.pushName}`,
 //previewType: "PHOTO",
 thumbnail: fs.readFileSync('./media/menu.jpg'),
 renderLargerThumbnail: true,
 mediaUrl: null,
 sourceUrl: null,
 },
 forwardedNewsletterMessageInfo: {
 newsletterJid: my.idch,
 serverMessageId: -1,
 newsletterName: `Menu By: ${namaowner}`,
 }
 }
}, { quoted: null });
let kate = await fetchJson('https://raw.githubusercontent.com/ditss-dev/database/main/kata%20kata%20hari%20ini.json');
let pinkk = kate[Math.floor(Math.random() * kate.length)];
let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/database/main/music.json');
let itil = pler[Math.floor(Math.random() * pler.length)];
await Ditss.sendMessage(m.chat, { audio: { url: itil}, mimetype: 'audio/mpeg', ptt: true,
  contextInfo: {
    mentionedJid: [m.sender],
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: global.my.idch,
      newsletterName: `alo ${m.pushName}🫣`,
      serverMessageId: 143
    }
  }
}, { 
  quoted: {
    key: { 
      fromMe: false, 
      participant: m.sender, 
      id: 'fake-msg-id' 
    },
    message: { 
      conversation: pinkk
    }
  }
})

}


handler.command = ["menupopuler", "populermenu", "asuma-populer", "ditsspopuler",]

module.exports = handler