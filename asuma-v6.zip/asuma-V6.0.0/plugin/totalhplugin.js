const fs = require("fs");
const path = require("path");
const pluginsFolderPath = './plugin';
let handler = async (m, { pulsar, prefix, command }) => {
  try {
    const pluginFiles = fs.readdirSync(pluginsFolderPath);
    const jsFiles = pluginFiles.filter(file => file.endsWith(".js"));
    if (jsFiles.length === 0) {
      return m.reply("Tidak ada file plugin ditemukan di folder plugins.");
    }
    let detectedCommands = 0;
    for (const file of jsFiles) {
      const filePath = path.join(pluginsFolderPath, file);
      const fileContent = fs.readFileSync(filePath, "utf8");
      const commandMatches = fileContent.match(/handler\.command\s*=\s*\[(.*?)\]/);
      if (commandMatches) {
        const commands = commandMatches[1].split(',').map(cmd => cmd.trim().replace(/['"]/g, ''));
        detectedCommands += commands.length;
      }
    }

    const totalFitur = () => {
      try {
        const mytext = fs.readFileSync('./pulsar.js', 'utf8');
        const numCases = (mytext.match(/(?<!\/\/)(case\s+['"][^'"]+['"])/g) || [])
          .length;
        return numCases;
      } catch (err) {
        console.error('Error:', err);
        return 0;
      }
    };

    if (detectedCommands > 0) {
      m.reply(`
*Total Plugin:* ${jsFiles.length}
*Fitur:* ${detectedCommands}

*Total Fitur Case:* ${totalFitur()}

*TOTAL FITUR ${detectedCommands + totalFitur()}*
`);
    } else {
      m.reply("Invalid.");
    }
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan saat memeriksa file plugin.");
  }
};

handler.help = ["totalplug"];
handler.tags = ["plugin"];
handler.command = ["totalplug", "totalplugin", "totalpl" ,"ttf", "totalfitur", "totalfeature"];

module.exports = handler;
