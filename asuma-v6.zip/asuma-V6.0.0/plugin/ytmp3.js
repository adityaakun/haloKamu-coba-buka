const fs = require("fs");
const { execSync } = require("child_process");


let handler = async (m, {Ditss,  isCreator }) => {
    if (!isCreator) return m.reply('KONTOL');
    try {
        m.reply('Mengumpulkan semua file ke folder...');
        const ls = execSync("ls").toString().split("\n").filter((file) =>
            file !== "node_modules" &&
            file !== "sessionn" &&
            file !== "package-lock.json" &&
            file !== "yarn.lock" &&
            file !== ""
        );

        console.log("File yang akan dibackup:", ls);
        const escapedFiles = ls.map(file => `"${file}"`).join(" ");
        execSync(`zip -r Backup.zip ${escapedFiles}`);

        if (!fs.existsSync('./Backup.zip')) {
            return m.reply('File ZIP tidak ditemukan, proses backup gagal.');
        }
        await Ditss.sendMessage(m.sender, {
            document: fs.readFileSync('./Backup.zip'),
            mimetype: "application/zip",
            fileName: "Backup.zip",
        });
        execSync("rm -rf Backup.zip");

        m.reply('Backup selesai dan file berhasil dikirim ke owner.');
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan saat proses backup.');
    }
};

handler.help = ['backup'];
handler.tags = ['owner'];
handler.command = ["backup", "bcsc", "backupsc"];
module.exports = handler;
