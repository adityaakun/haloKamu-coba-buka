const fs = require("fs")

const os = require('os');

let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime, fdoc, qkontak, ditsganteng, fetchJson}) => {

let teksnya = `${global.menubug}`

await Ditss.sendMessage(m.chat, {document: fs.readFileSync("./asuma-Ditss.js"), mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", caption: `${teksnya}`, fileName: `${namabot} V${global.versi}`, contextInfo: {

isForwarded: true, 

forwardingScore: 9999, 

businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${global.namabot}`, newsletterJid: global.idSaluran }, 

mentionedJid: [global.owner+"@s.whatsapp.net", m.sender], externalAdReply: {containsAutoReply: true, thumbnail: await fs.readFileSync("./media/menu.jpg"), title: `© Copyright By ${namaowner}`, 

renderLargerThumbnail: true, sourceUrl: my.linkch, mediaType: 1}}}, {quoted: qtext})

let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/database/main/music.json');

let itil = pler[Math.floor(Math.random() * pler.length)];

await Ditss.sendMessage(m.chat, { audio:{url: itil},mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: fdoc })}

handler.command = ["menubug", "bugmenu", "asuma-bug", "ditssbug"]

module.exports = handler