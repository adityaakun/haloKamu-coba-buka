const fs = require("fs")
const path = require('path');

let handler = async (m, { Ditss, isOwner, text, Reply, example }) => {
if (!isOwner) return Reply(global.msg.owner)
let dir = fs.readdirSync('./plugin')
if (dir.length < 1) return m.reply("Tidak ada file plugins")
let teks = "\n"
for (let e of dir) {
teks += `* ${e}\n`
}
m.reply(teks)
}

handler.command = ["listplugin", "listplugins"]

module.exports = handler